// ALexander Kissi jr
// info@alexkissijr.com
// CopyRight 2023

#include <wx/wx.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

class MyFrame : public wxFrame
{
public:
    MyFrame(const wxString& title)
        : wxFrame(nullptr, wxID_ANY, title)
    {
        // Load the image using OpenCV
        cv::Mat image = cv::imread("image.png");

        // Convert the OpenCV image to wxWidgets format
        wxImage wximg(image.cols, image.rows, image.data, true);
        wxBitmap bitmap(wximg);

        // Create an image control and display the image
        wxStaticBitmap* staticBitmap = new wxStaticBitmap(this, wxID_ANY, bitmap);

        // Create a button for user interaction
        wxButton* drawButton = new wxButton(this, wxID_ANY, "Draw Boundary");
        wxButton* applyButton = new wxButton(this, wxID_ANY, "Apply Boundary Correction");

        // Register event handlers for the button click events
        drawButton->Bind(wxEVT_BUTTON, &MyFrame::OnDrawButtonClicked, this);
        applyButton->Bind(wxEVT_BUTTON, &MyFrame::OnApplyButtonClicked, this);

        // Create a sizer to arrange the controls
        wxBoxSizer* sizer = new wxBoxSizer(wxVERTICAL);
        sizer->Add(staticBitmap, 0, wxALIGN_CENTER | wxALL, 10);
        sizer->Add(drawButton, 0, wxALIGN_CENTER | wxALL, 10);
        sizer->Add(applyButton, 0, wxALIGN_CENTER | wxALL, 10);

        // Set the sizer for the frame
        SetSizerAndFit(sizer);
        Centre();
    }

    void OnDrawButtonClicked(wxCommandEvent& event)
    {
        // Load the image using OpenCV
        cv::Mat image = cv::imread("image.png");

        // Create an empty black image with the same size as the loaded image
        boundaryImage_ = cv::Mat::zeros(image.size(), CV_8UC3);

        // Create a window for user interaction
        cv::namedWindow("Draw Boundary");

        // Set up the mouse callback function for drawing the boundary
        cv::setMouseCallback("Draw Boundary", mouseCallback, this);

        // Main loop for drawing the boundary
        while (true)
        {
            // Display the image with the current boundary
            cv::Mat displayedImage = image + boundaryImage_;
            cv::imshow("Draw Boundary", displayedImage);

            // Wait for key press
            int key = cv::waitKey(1);

            // If the user presses the 'Esc' key, exit the loop
            if (key == 27)
                break;
        }

        // Close the window
        cv::destroyWindow("Draw Boundary");
    }

    void OnApplyButtonClicked(wxCommandEvent& event)
    {
        // Load the image using OpenCV
        cv::Mat image = cv::imread("image.png");

        // Apply the boundary correction to the image
        cv::Mat correctedImage = applyBoundaryCorrection(image, boundaryImage_);

        // Save the corrected image to a new file
        cv::imwrite("corrected_image.png", correctedImage);

        wxMessageBox("Boundary Correction Applied and Image Saved!", "Information", wxOK | wxICON_INFORMATION);
    }

    static void mouseCallback(int event, int x, int y, int flags, void* userdata)
    {
        MyFrame* frame = static_cast<MyFrame*>(userdata);
        frame->HandleMouseCallback(event, x, y, flags);
    }

    void HandleMouseCallback(int event, int x, int y, int flags)
    {
        if (event == cv::EVENT_LBUTTONDOWN)
        {
            // Start drawing the boundary
            drawingMode_ = true;
            boundaryPoints_.clear();
            boundaryPoints_.push_back(cv::Point(x, y));
        }
        else if (event == cv::EVENT_LBUTTONUP)
        {
            // Finish drawing the boundary
            drawingMode_ = false;
            boundaryPoints_.push_back(cv::Point(x, y));

            // Generate a smoother filled polygon using approximation
            if (boundaryPoints_.size() >= 3)
            {
                std::vector<std::vector<cv::Point>> contours;
                contours.push_back(boundaryPoints_);

                // Create a mask for the boundary
                cv::Mat boundaryMask = cv::Mat::zeros(boundaryImage_.size(), CV_8UC1);
                cv::drawContours(boundaryMask, contours, -1, cv::Scalar(255), cv::FILLED);

                // Smooth the boundary mask
                cv::Mat smoothedBoundaryMask;
                cv::GaussianBlur(boundaryMask, smoothedBoundaryMask, cv::Size(9, 9), 0);

                // Apply the smoothed boundary mask to the boundary image
                cv::Mat correctedBoundaryImage;
                boundaryImage_.copyTo(correctedBoundaryImage, smoothedBoundaryMask);

                // Update the boundary image with the corrected boundary
                boundaryImage_ = correctedBoundaryImage.clone();
            }
        }
        else if (event == cv::EVENT_MOUSEMOVE && drawingMode_)
        {
            // Continue drawing the boundary
            boundaryPoints_.push_back(cv::Point(x, y));
            cv::line(boundaryImage_, boundaryPoints_[boundaryPoints_.size() - 2], boundaryPoints_[boundaryPoints_.size() - 1], cv::Scalar(0, 0, 255), 2);
        }
    }

    cv::Mat applyBoundaryCorrection(const cv::Mat& image, const cv::Mat& boundaryImage)
    {
        // Convert the boundary image to grayscale
        cv::Mat grayBoundary;
        cv::cvtColor(boundaryImage, grayBoundary, cv::COLOR_BGR2GRAY);

        // Find contours of the boundary image
        std::vector<std::vector<cv::Point>> contours;
        cv::findContours(grayBoundary, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

        // Create a mask for the corrected boundary
        cv::Mat correctedBoundary = cv::Mat::zeros(image.size(), CV_8UC1);
        cv::drawContours(correctedBoundary, contours, -1, cv::Scalar(255), cv::FILLED);

        // Create a blue fill color for the corrected boundary
        cv::Scalar fillColor(255, 0, 0); // Blue color (BGR order)

        // Dilate the corrected boundary to match the thickness of the veins
        int dilationSize = 5; // Adjust the dilation size to control the thickness
        cv::Mat dilatedBoundary;
        cv::dilate(correctedBoundary, dilatedBoundary, cv::getStructuringElement(cv::MORPH_RECT, cv::Size(dilationSize, dilationSize)));

        // Apply the dilated boundary as a mask to the original image
        cv::Mat correctedImage = image.clone();
        correctedImage.setTo(fillColor, dilatedBoundary);

        // Draw the boundary on the corrected image with red color
        cv::Scalar outlineColor(0, 0, 255); // Red color (BGR order)
        cv::drawContours(correctedImage, contours, -1, outlineColor, 2, cv::LINE_AA);

        return correctedImage;
    }

private:
    cv::Mat boundaryImage_;
    std::vector<cv::Point> boundaryPoints_;
    bool drawingMode_ = false;
};

class MyApp : public wxApp
{
public:
    virtual bool OnInit()
    {
        MyFrame* frame = new MyFrame("Boundary Correction App");
        frame->Show();
        return true;
    }
};

wxIMPLEMENT_APP(MyApp);
